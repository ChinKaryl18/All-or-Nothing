# Simple Brew Cafe Website

A responsive, three-page cafe website created for **Activity 01: ALL OR NOTHING** using HTML5 and CSS3 only.

## Pages
- `index.html` — homepage and featured drinks
- `about.html` — cafe story, values, and visit information
- `gallery.html` — menu and visual gallery

## Folder structure
```text
simple-brew-cafe/
├── index.html
├── about.html
├── gallery.html
├── css/
│   └── style.css
├── images/
└── README.md
```

## Technology and compliance
- HTML5 and CSS3 only
- No JavaScript, JavaScript libraries, or frameworks
- Responsive layouts using CSS media queries
- Navigation uses ordinary HTML links and page anchors
- Decorative drink and cafe illustrations are made with CSS

## Preview locally
Open `index.html` in a web browser. Keep the `css` folder beside the HTML files so the stylesheet path works.

## Publish with GitHub Pages
1. Create a **public** repository on GitHub, for example `simple-brew-cafe`.
2. Upload the contents of this folder (the HTML files, `css` folder, and README).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish. Your website URL will appear in the Pages settings.

## Before submitting
- Replace the sample address, email, opening hours, and menu prices with your actual details if needed.
- Test every navigation link on desktop and mobile widths.
- Confirm the repository is public and the GitHub Pages URL opens.
